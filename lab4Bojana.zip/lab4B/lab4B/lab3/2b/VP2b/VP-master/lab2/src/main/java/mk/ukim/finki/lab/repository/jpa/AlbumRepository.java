package mk.ukim.finki.lab.repository.jpa;

import mk.ukim.finki.lab.model.Album;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AlbumRepository extends JpaRepository<Album, Long> {
    Optional<Album> findById(Long id);

    //    List<Album> findById(long id);
}
