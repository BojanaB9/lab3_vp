package mk.ukim.finki.lab.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class WebSecurtiyConfig {


    private final PasswordEncoder passwordEncoder;


    public WebSecurtiyConfig(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .headers((headers) -> headers
            .frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin)
            )
                .authorizeHttpRequests((requests) -> requests
                        .requestMatchers("/", "/songs", "/assets/**", "/register")
                        .permitAll()
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .anyRequest()
                        .authenticated()
                )
                .formLogin((form) -> form

                        .defaultSuccessUrl("/songs", true)
                )
                .logout((logout) -> logout
                                .logoutUrl("/logout")
                                .clearAuthentication(true)
                                .invalidateHttpSession(true)
                                .deleteCookies("JSESSIONID")
                                .logoutSuccessUrl("/login")


                );


        return http.build();
    }



    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user1= User.builder()
                .username("gamze.mustafa")
                .password(passwordEncoder.encode("gm"))
                .roles("ADMIN")
                .build();
        UserDetails  user2= User.builder()
                .username("finki.user")
                .password(passwordEncoder.encode("fu"))
                .roles("USER")
                .build();
        return new InMemoryUserDetailsManager(user1, user2);
        //bureyeka calisti user em config le ama lofinde bad credentials verdi
    }



}


