package mk.ukim.finki.lab.controller;

import mk.ukim.finki.lab.model.Artist;
import mk.ukim.finki.lab.service.ArtistService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ArtistController {

    private final ArtistService artistService;

    public ArtistController(ArtistService artistService) {
        this.artistService = artistService;
    }

    @GetMapping("/artist/artistsList")
    public String getArtistsList(Model model) {
        List<Artist> artistList = artistService.listArtists();
        model.addAttribute("artistList", artistList);
        return "artistsList";
    }

    @PostMapping("/artist/artistsList")
    public String addArtistToSong(@RequestParam(required = false) String songRadio, Model model) {
        String trackId = (songRadio != null) ? songRadio : "-";
        List<Artist> artistList = artistService.listArtists();

        model.addAttribute("trackId", trackId);
        model.addAttribute("artistList", artistList);
        return "artistsList";
    }
}
