﻿namespace Shop.Domain
{
    public class Class1
    {

    }
}
