﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Domain.DomainModels
{
    public class Order : BaseEntity
    {
        public Guid UserId { get; set; }
        public ShopUser User { get; set; }

        public DateTime CreatedAt { get; set; }
        public decimal TotalPrice { get; set; }

        public ICollection<OrderItem> OrderItems { get; set; }
    }

}
