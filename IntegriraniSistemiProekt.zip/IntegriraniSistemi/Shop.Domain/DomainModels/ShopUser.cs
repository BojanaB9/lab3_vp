﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace Shop.Domain.DomainModels
{
    public class ShopUser : IdentityUser
    {
        public ICollection<Order> Orders { get; set; }
    }
}
