﻿using Microsoft.AspNetCore.Mvc;
using Shop.Domain.DomainModels;
using Shop.Service.Interface;



namespace Shop.Web.Controllers
{
    public class BooksController : Controller
    {
        private readonly IBookService _bookService;
        private readonly IDataFetchService _dataFetchService;

        public BooksController(
            IBookService bookService,
            IDataFetchService dataFetchService)
        {
            _bookService = bookService;
            _dataFetchService = dataFetchService;
        }

        // GET: Books
        public IActionResult Index()
        {
            return View(_bookService.GetAll());
        }

        // GET: Books/Details/5
        public IActionResult Details(Guid? id)
        {
            if (id == null)
                return NotFound();

            var book = _bookService.GetById(id.Value);
            if (book == null)
                return NotFound();

            return View(book);
        }

        // GET: Books/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Books/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _bookService.Insert(book);
                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: Books/Edit/5
        public IActionResult Edit(Guid? id)
        {
            if (id == null)
                return NotFound();

            var book = _bookService.GetById(id.Value);
            if (book == null)
                return NotFound();

            return View(book);
        }

        // POST: Books/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Guid id, Book book)
        {
            if (id != book.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                _bookService.Update(book);
                return RedirectToAction(nameof(Index));
            }

            return View(book);
        }

        // GET: Books/Delete/5
        public IActionResult Delete(Guid? id)
        {
            if (id == null)
                return NotFound();

            var book = _bookService.GetById(id.Value);
            if (book == null)
                return NotFound();

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(Guid id)
        {
            _bookService.DeleteById(id);
            return RedirectToAction(nameof(Index));
        }

        // GET: Books/Fetch
        public async Task<IActionResult> Fetch()
        {
            await _dataFetchService.FetchBooksFromApi("programming");
            return RedirectToAction(nameof(Index));
        }
    }
}
