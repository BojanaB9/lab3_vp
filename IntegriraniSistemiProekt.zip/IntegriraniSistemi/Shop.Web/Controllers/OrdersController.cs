﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Shop.Domain.DTO;
using Shop.Service.Interface;

namespace Shop.Web.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orderService;
        private readonly IBookService _bookService;

        public OrdersController(
            IOrderService orderService,
            IBookService bookService)
        {
            _orderService = orderService;
            _bookService = bookService;
        }

        // GET: Orders
        public IActionResult Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return View(_orderService.GetAll());
        }

        // GET: Orders/Create
        public IActionResult Create(Guid bookId)
        {
            ViewData["Book"] = _bookService.GetById(bookId);
            return View();
        }

        // POST: Orders/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(AddToCartDTO dto)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Order creation logic is in the service
            _orderService.CreateOrder(userId, dto.BookId, dto.Quantity);

            return RedirectToAction(nameof(Index));
        }
    }
}
