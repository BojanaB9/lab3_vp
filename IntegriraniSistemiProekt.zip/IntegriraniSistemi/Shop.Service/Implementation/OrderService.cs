﻿using Shop.Domain.DomainModels;
using Shop.Repository.Interface;
using Shop.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Service.Implementation
{
    public class OrderService : IOrderService
    {
        private readonly IRepository<Order> _repository;

        public OrderService(IRepository<Order> repository)
        {
            _repository = repository;
        }

        public List<Order> GetAll()
        {
            return _repository.GetAll(
                selector: x => x,
                include: x => x.Include(o => o.OrderItems)
                               .ThenInclude(oi => oi.Book)
            ).ToList();
        }

        public Order? GetById(Guid id)
        {
            return _repository.Get(
                selector: x => x,
                predicate: x => x.Id == id,
                include: x => x.Include(o => o.OrderItems)
                               .ThenInclude(oi => oi.Book)
            );
        }

        public Order Insert(Order order)
        {
            return _repository.Insert(order);
        }

        public Order Update(Order order)
        {
            return _repository.Update(order);
        }

        public Order DeleteById(Guid id)
        {
            var entity = GetById(id);

            if (entity == null)
                throw new ArgumentNullException("");

            return _repository.Delete(entity);
        }
    }
}
