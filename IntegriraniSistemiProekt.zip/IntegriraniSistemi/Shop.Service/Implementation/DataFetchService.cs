﻿using Shop.Domain.DomainModels;
using Shop.Service.Interface;
using Shop.Domain.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Service.Implementation
{
    public class DataFetchService : IDataFetchService
    {
        private readonly HttpClient _httpClient;
        private readonly IBookService _bookService;

        public DataFetchService(
            IHttpClientFactory httpClientFactory,
            IBookService bookService)
        {
            _httpClient = httpClientFactory.CreateClient();
            _bookService = bookService;
        }

        public async Task<List<Book>> FetchBooksFromApi(string query)
        {
            var response =
                await _httpClient.GetFromJsonAsync<GoogleBooksResponseDTO>(
                    $"https://www.googleapis.com/books/v1/volumes?q={query}");

            var books = new List<Book>();

            if (response?.Items == null)
                return books;

            foreach (var item in response.Items)
            {
                var volume = item.VolumeInfo;

                if (volume == null)
                    continue;

                books.Add(new Book
                {
                    Id = Guid.NewGuid(),
                    Title = volume.Title ?? "Unknown title",
                    Author = volume.Authors != null && volume.Authors.Any()
                        ? volume.Authors[0]
                        : "Unknown author",
                    ISBN = volume.IndustryIdentifiers != null && volume.IndustryIdentifiers.Any()
                        ? volume.IndustryIdentifiers[0].Identifier
                        : "",
                    Description = volume.Description ?? "",
                    Price = 10,
                    Stock = 10
                });
            }

            _bookService.InsertMany(books);
            return books;
        }
    }
}
