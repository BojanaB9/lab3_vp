﻿using Shop.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Service.Interface
{
    public interface IOrderService
    {
        List<Order> GetAll();
        Order? GetById(Guid id);
        Order Insert(Order order);
        Order Update(Order order);
        Order DeleteById(Guid id);
    }
}
