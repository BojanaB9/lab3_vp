﻿using Shop.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Service.Interface
{
    public interface IDataFetchService
    {
        Task<List<Book>> FetchBooksFromApi(string query);
    }
}
