﻿namespace Shop.Service
{
    public class Class1
    {

    }
}
