﻿using Microsoft.EntityFrameworkCore;

using Shop.Domain.DomainModels;
using Shop.Repository.Dataa;
using Shop.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Repository.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly DbSet<ShopUser> _entities;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
            _entities = context.Set<ShopUser>();
        }

        public ShopUser? GetById(string id)
        {
            return _entities
                .Include(u => u.Orders)
                .FirstOrDefault(u => u.Id == id);
        }

        public ShopUser? GetByEmail(string email)
        {
            return _entities
                .FirstOrDefault(u => u.Email == email);
        }
    }
}
